#include <string.h>
#include <stdio.h> 

#include <Common/config.h>

int main(void)
{
	printf ("navdata_port:%d\n", get_navdata_port());

	return 0;
}

