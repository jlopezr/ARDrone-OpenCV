#ifndef _MATHS_TIME_H_
#define _MATHS_TIME_H_

#include <VP_Os/vp_os_types.h>

float32_t time_in_ms_f(void);

#endif // _TIME_H_
