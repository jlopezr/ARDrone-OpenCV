#import <UIKit/UIKit.h>
#import "MenuController.h"
#import "ARDrone.h"
#import "EAGLView.h"

@interface MenuDrone : UIViewController <MenuProtocol, ARDroneProtocolIn>
{
 	MenuController* controller;
}

@end
