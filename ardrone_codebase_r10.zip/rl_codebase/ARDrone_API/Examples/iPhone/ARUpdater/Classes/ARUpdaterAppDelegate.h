//
//  ARUpdaterAppDelegate.h
//  AR.Updater
//
//  Created by Robert Ryll on 10-05-14.
//  Copyright Playsoft 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ARUpdaterViewController;

@interface ARUpdaterAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ARUpdaterViewController *viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) ARUpdaterViewController *viewController;

@end

