#include <VP_Os/vp_os_print.h>
#include <ATcodec/ATcodec_api.h>

#include <AT_Processing/at_msgs_impl.h>

AT_CODEC_ERROR_CODE atresu_ok(ATcodec_Memory_t *mem, ATcodec_Memory_t *output, int *id)
{
  return AT_CODEC_GENERAL_OK;
}

AT_CODEC_ERROR_CODE atresu_error(ATcodec_Memory_t *mem, ATcodec_Memory_t *output, int *id)
{
  return AT_CODEC_GENERAL_OK;
}
