/*
 *  control_ack.h
 *  ARDroneEngine
 *
 *  Created by Mykonos on 25/03/10.
 *  Copyright 2010 Parrot SA. All rights reserved.
 *
 */
#ifndef _PARROT_CONTROL_CFG_H_
#define _PARROT_CONTROL_CFG_H_
#include "ConstantsAndMacros.h"

void control_cfg_init(void);
bool_t control_get_configuration(void);

extern ardrone_config_t ardrone_control_config;
extern const ardrone_config_t ardrone_control_config_default;

#endif // _PARROT_CONTROL_CFG_H_